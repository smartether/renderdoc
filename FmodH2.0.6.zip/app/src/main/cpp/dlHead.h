//
// Created by qianzhengwei on 2021/5/27.
//

#ifndef FMODH_DLHEAD_H
#define FMODH_DLHEAD_H
#include "fmodInc/fmod.h"
typedef FMOD_RESULT (*memory_init_func)(void *poolmem, int poollen, FMOD_MEMORY_ALLOC_CALLBACK useralloc, FMOD_MEMORY_REALLOC_CALLBACK userrealloc, FMOD_MEMORY_FREE_CALLBACK userfree, FMOD_MEMORY_TYPE memtypeflags);
typedef FMOD_RESULT (*memory_getstates_func)(int *currentalloced, int *maxalloced, FMOD_BOOL blocking);
typedef FMOD_RESULT (*debug_initialize_func)(FMOD_DEBUG_FLAGS flags, FMOD_DEBUG_MODE mode, FMOD_DEBUG_CALLBACK callback, const char *filename);
typedef FMOD_RESULT (*file_setdiskbusy_func)(int busy);
typedef FMOD_RESULT (*file_getdiskbusy_func)(int *busy);
//typedef FMOD_RESULT (*thread_setattributes_func)(FMOD_THREAD_TYPE type, FMOD_THREAD_AFFINITY affinity, FMOD_THREAD_PRIORITY priority, FMOD_THREAD_STACK_SIZE stacksize);
typedef FMOD_RESULT (*system_create_func)(FMOD_SYSTEM **system, unsigned int headerversion);

static void* fmoeHandle;

static memory_init_func memory_Initialize;
static memory_getstates_func memory_GetStats;
static debug_initialize_func debug_initialize;
static file_setdiskbusy_func file_setdiskbusy;
static file_getdiskbusy_func file_getdiskbusy;
//static thread_setattributes_func thread_setattributes;
static system_create_func system_create;



#endif //FMODH_DLHEAD_H
