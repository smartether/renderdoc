#include <jni.h>
#include <string>
#include <dlfcn.h>
#include <android/log.h>
#include "fmodInc/fmod.h"
#include "dlHead.h"
#include "fmodInc/fmod.hpp"
#include <dlfcn.h>
#include "dlHead.h"
#include <android/log.h>

//extern "C" JNIEXPORT jstring JNICALL
//Java_com_example_fmodh_MainActivity_stringFromJNI(
//        JNIEnv* env,
//        jobject /* this */) {
//    std::string hello = "Hello from C++";
//    return env->NewStringUTF(hello.c_str());
//}




extern "C" JNIEXPORT jint JNICALL  JNI_OnLoad(JavaVM* vm, void* reserved)
    {
//        auto libFmod = dlopen("libfmod1.so", RTLD_LOCAL);
//        auto System_release = dlsym(libFmod, "FMOD::System::release(void)");
        //__android_log_print(ANDROID_LOG_DEBUG, "FMOD", "$$ fmod loaded...");
        fmoeHandle = dlopen("libfmoe.so",  RTLD_LOCAL | RTLD_LAZY);
        memory_Initialize = (memory_init_func)dlsym(fmoeHandle, "FMOD_Memory_Initialize");
    memory_GetStats = (memory_getstates_func)dlsym(fmoeHandle, "FMOD_Memory_GetStats");
    debug_initialize = (debug_initialize_func)dlsym(fmoeHandle, "FMOD_Debug_Initialize");
    file_setdiskbusy = (file_setdiskbusy_func)dlsym(fmoeHandle, "FMOD_File_SetDiskBusy");
    file_getdiskbusy = (file_getdiskbusy_func)dlsym(fmoeHandle, "FMOD_File_GetDiskBusy");
//    thread_setattributes = (thread_setattributes_func)dlsym(fmoeHandle, "FMOD_Thread_SetAttributes");
    system_create = (system_create_func)dlsym(fmoeHandle, "FMOD_System_Create");
    __android_log_print(ANDROID_LOG_DEBUG, "$$FMOD", "FMOD_VERSION:%i", FMOD_VERSION);
//       FMOD_SYSTEM *sys;
//        system_create(&sys, FMOD_VERSION);
        return JNI_VERSION_1_6;
    }

FMOD_RESULT F_API FMOD_Memory_Initialize(void *poolmem, int poollen, FMOD_MEMORY_ALLOC_CALLBACK useralloc, FMOD_MEMORY_REALLOC_CALLBACK userrealloc, FMOD_MEMORY_FREE_CALLBACK userfree, FMOD_MEMORY_TYPE memtypeflags)
{
    //return FMOD::Memory_Initialize(poolmem, poollen, useralloc, userrealloc, userfree, memtypeflags);
    return memory_Initialize(poolmem, poollen, useralloc, userrealloc, userfree, memtypeflags);
}
FMOD_RESULT F_API FMOD_Memory_GetStats(int *currentalloced, int *maxalloced, FMOD_BOOL blocking)
{
//   return FMOD::Memory_GetStats(currentalloced, maxalloced, blocking);
    return memory_GetStats(currentalloced, maxalloced, blocking);
}
FMOD_RESULT F_API FMOD_Debug_Initialize(FMOD_DEBUG_FLAGS flags, FMOD_DEBUG_MODE mode, FMOD_DEBUG_CALLBACK callback, const char *filename)
{
//   return FMOD::Debug_Initialize(flags, mode, callback, filename);
    return debug_initialize(flags, mode, callback, filename);

}
FMOD_RESULT F_API FMOD_File_SetDiskBusy(int busy)
{
//   return FMOD::File_SetDiskBusy(busy);
    return file_setdiskbusy(busy);

}
FMOD_RESULT F_API FMOD_File_GetDiskBusy(int *busy)
{
//   return FMOD::File_GetDiskBusy(busy);
    return file_getdiskbusy(busy);

}
//FMOD_RESULT F_API FMOD_Thread_SetAttributes(FMOD_THREAD_TYPE type, FMOD_THREAD_AFFINITY affinity, FMOD_THREAD_PRIORITY priority, FMOD_THREAD_STACK_SIZE stacksize)
//{
////   return FMOD::Thread_SetAttributes(type, affinity, priority, stacksize);
//    return thread_setattributes(type, affinity, priority, stacksize);
//
//
//}
FMOD_RESULT F_API FMOD_System_Create(FMOD_SYSTEM **system, unsigned int headerversion)
{
//   return FMOD::System_Create((FMOD::System**)system, headerversion);
    __android_log_print(ANDROID_LOG_DEBUG, "$$FMOD", "headerVersion:%i", headerversion);
    return system_create(system, headerversion);
}
FMOD_RESULT F_API FMOD_System_Release(FMOD_SYSTEM *system)
{
    return ((FMOD::System*)system)->release();


}
